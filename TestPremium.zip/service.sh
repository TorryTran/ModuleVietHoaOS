#!/system/bin/sh
MODDIR=${0%/*}

# Chống treo máy by hiếu kakathic ( 60s tự tắt hết module)
while [ "$(getprop sys.boot_completed)" != "1" ]; do
Auto=$(($Auto + 1))
if [ "$Auto" == 60 ];then
    for Vak in /data/adb/modules/*; do
    echo > $Vak/disable
       if [ -d /data/adb/service.d/ ]; then
          touch /data/adb/service.d/TorryTran.sh
          NOFI_BOOTLOOP="sleep 10; su -lp 2000 -c \"cmd notification post -S bigtext -t 'Module Việt Hoá HyperOS' 'Tag' 'Module Việt Hoá đã phát hiện thiết bị bạn bị bootloop và đã tự động kích hoạt tính năng chống treo máy!! Hãy vào Magisk kiểm tra lại tất cả module của bạn!'\"; rm -rf /data/adb/service.d/TorryTran.sh"
          echo $NOFI_BOOTLOOP > /data/adb/service.d/TorryTran.sh
          chmod +x /data/adb/service.d/TorryTran.sh
       fi
    done
    reboot
fi
sleep 1
done

# Chặn quản cáo bằng dns
settings put global private_dns_specifier dns.adguard.com

# Tắt zram cho máy 12GB+
ram=$(free -g | awk '/^Mem:/{print $2}')
if [ $ram -ge 10 ]; then
alias SWAPT='grep -i SwapTotal /proc/meminfo | tr -d [:alpha:]:" "'
until [ "$(getprop sys.boot_completed)" = 1 ]
   do
   sleep 1
   done
TL=60
Step=3
k=0
while [ $(SWAPT) -eq 0  ]
do
    k=$(( $k + $Step ))
    if [ $k -gt $TL  ] ; then
        exit 0
    fi
    sleep $Step
done
SR="\/dev\/"
PS="/proc/swap*"
if [ -f /system/bin/swapoff ] ; then
    SO="/system/bin/swapoff"
else
    SO="swapoff"
fi
DIE=$(awk -v SBD="$SR" ' $0 ~ SBD {
      for ( i=1;i<=NF;i++ )
        {
          if ( $i ~ ( "^" SBD ) )
           {
              printf "%s;", $i
              break
           }
        }
      }' $PS)
saveifs=$IFS
IFS=';'
for i in $DIE
do
    case $i in
        *zram*)
              j=$(echo $i | sed 's/.*zram//')
              ( ( 
                 echo $j > /sys/class/zram-control/hot_remove
                 echo 1 > /sys/block/zram${j}/reset
                 $SO $i
              ) & )
              ;;
        *)
              if [ -n $i ]; then
                  ( ( $SO $i ) & ) 
              fi
              ;;
    esac
done
IFS=$saveifs
  else 
  sleep 1
  fi
  

# Fix thông báo by Hiếu kakathic
for auto in $(pm list packages -3 | cut -d : -f2); do
dumpsys deviceidle whitelist +$auto
am set-standby-bucket $auto active
set $auto START_FOREGROUND allow
set $auto RUN_ANY_IN_BACKGROUND allow
set $auto RUN_IN_BACKGROUND allow
set $auto 10008 allow
done

# Gỡ một vài ứng dụng ko cần thiết 
pm uninstall -k --user 0 com.miui.analytics
pm uninstall -k --user 0 com.miui.accessibility
pm uninstall -k --user 0 com.miui.voiceassist
pm uninstall -k --user 0 com.xiaomi.aicr
pm uninstall -k --user 0 com.miui.securityinputmethod
pm uninstall -k --user 0 com.miui.daemon
pm uninstall -k --user 0 com.android.quicksearchbox
pm uninstall -k --user 0 com.xiaomi.aiasst.vision
pm uninstall -k --user 0 com.xiaomi.aiasst.service
pm uninstall -k --user 0 com.xiaomi.aiasst.vision
pm uninstall -k --user 0 com.xiaomi.aireco
pm uninstall -k --user 0 com.xiaomi.mis
pm uninstall -k --user 0 com.sohu.inputmethod.sogou.xiaomi
pm uninstall -k --user 0 com.xiaomi.gamecenter.sdk.service
pm uninstall -k --user 0 com.unionpay.tsmservice.mi
pm uninstall -k --user 0 com.android.browser
pm uninstall -k --user 0 com.miui.carlink
pm uninstall -k --user 0 com.miui.voicetrigger
exit 0

